// برنامج تحميل بيانات الوسطاء حسب المنطقة
const regionsData = {};
let loadedRegions = [];

// تحميل فهرس المناطق
async function loadRegionsIndex() {
    try {
        const response = await fetch('regions_index.json');
        const indexData = await response.json();
        return indexData;
    } catch (error) {
        console.error('خطأ في تحميل فهرس المناطق:', error);
        return {};
    }
}

// تحميل بيانات منطقة محددة
async function loadRegionData(region) {
    if (loadedRegions.includes(region)) {
        return regionsData[region];
    }
    
    try {
        const response = await fetch(`region_${region.replace(' ', '_')}.json`);
        const regionData = await response.json();
        regionsData[region] = regionData;
        loadedRegions.push(region);
        return regionData;
    } catch (error) {
        console.error(`خطأ في تحميل بيانات منطقة ${region}:`, error);
        return [];
    }
}

// البحث عن وسيط حسب رقم الجوال
async function findBrokerByPhone(phone) {
    const index = await loadRegionsIndex();
    
    // تحميل بيانات جميع المناطق بالتوازي
    const loadPromises = Object.keys(index).map(region => loadRegionData(region));
    await Promise.all(loadPromises);
    
    // البحث في جميع البيانات المحملة
    for (const region in regionsData) {
        const broker = regionsData[region].find(b => b.phone === phone);
        if (broker) {
            return broker;
        }
    }
    
    return null;
}

// تحميل بيانات الوسطاء حسب المنطقة
async function loadBrokersByRegion(region) {
    return await loadRegionData(region);
}
