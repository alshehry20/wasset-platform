/* سكريبت جافاسكريبت لتحسين أداء منصة "وسّط" للوسطاء العقاريين المرخصين */

// تهيئة المتغيرات العامة
const wasset = {
    init: function() {
        this.setupEventListeners();
        this.setupAnimations();
        this.setupForms();
        this.setupTabs();
        this.setupMobileMenu();
        this.setupLazyLoading();
        this.setupBrokerFeatures();
    },

    // إعداد مستمعي الأحداث
    setupEventListeners: function() {
        document.addEventListener('DOMContentLoaded', function() {
            console.log('منصة وسّط جاهزة!');
            
            // تفعيل التمرير السلس للروابط الداخلية
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        window.scrollTo({
                            top: target.offsetTop - 100,
                            behavior: 'smooth'
                        });
                    }
                });
            });
            
            // تفعيل أزرار المشاركة
            const shareButtons = document.querySelectorAll('.share-button');
            if (shareButtons.length > 0) {
                shareButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        const url = this.dataset.url || window.location.href;
                        const title = this.dataset.title || document.title;
                        
                        if (navigator.share) {
                            navigator.share({
                                title: title,
                                url: url
                            }).catch(console.error);
                        } else {
                            // نسخ الرابط إلى الحافظة
                            const tempInput = document.createElement('input');
                            document.body.appendChild(tempInput);
                            tempInput.value = url;
                            tempInput.select();
                            document.execCommand('copy');
                            document.body.removeChild(tempInput);
                            
                            // إظهار رسالة تأكيد
                            const notification = document.createElement('div');
                            notification.className = 'notification';
                            notification.textContent = 'تم نسخ الرابط!';
                            document.body.appendChild(notification);
                            
                            setTimeout(() => {
                                notification.classList.add('show');
                            }, 10);
                            
                            setTimeout(() => {
                                notification.classList.remove('show');
                                setTimeout(() => {
                                    document.body.removeChild(notification);
                                }, 300);
                            }, 2000);
                        }
                    });
                });
            }
        });

        // تفعيل التمرير للأعلى
        const scrollTopButton = document.querySelector('.scroll-top');
        if (scrollTopButton) {
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    scrollTopButton.classList.add('show');
                } else {
                    scrollTopButton.classList.remove('show');
                }
            });
            
            scrollTopButton.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }
    },

    // إعداد الرسوم المتحركة
    setupAnimations: function() {
        // تفعيل الرسوم المتحركة عند التمرير
        const animatedElements = document.querySelectorAll('.animate-on-scroll');
        
        if (animatedElements.length > 0) {
            const animateOnScroll = function() {
                animatedElements.forEach(element => {
                    const elementTop = element.getBoundingClientRect().top;
                    const elementVisible = 150;
                    
                    if (elementTop < window.innerHeight - elementVisible) {
                        element.classList.add('animated');
                    }
                });
            };
            
            window.addEventListener('scroll', animateOnScroll);
            animateOnScroll(); // تشغيل مرة واحدة عند التحميل
        }
        
        // تفعيل العدادات
        const counters = document.querySelectorAll('.counter');
        
        if (counters.length > 0) {
            const countUp = function() {
                counters.forEach(counter => {
                    const elementTop = counter.getBoundingClientRect().top;
                    const elementVisible = 150;
                    
                    if (elementTop < window.innerHeight - elementVisible && !counter.classList.contains('counted')) {
                        counter.classList.add('counted');
                        
                        const target = parseInt(counter.getAttribute('data-target'));
                        const duration = 2000; // مدة العد بالمللي ثانية
                        const step = target / (duration / 16); // 16ms لكل إطار
                        
                        let current = 0;
                        const updateCounter = function() {
                            current += step;
                            if (current < target) {
                                counter.textContent = Math.floor(current);
                                requestAnimationFrame(updateCounter);
                            } else {
                                counter.textContent = target;
                            }
                        };
                        
                        updateCounter();
                    }
                });
            };
            
            window.addEventListener('scroll', countUp);
            countUp(); // تشغيل مرة واحدة عند التحميل
        }
    },

    // إعداد النماذج
    setupForms: function() {
        const forms = document.querySelectorAll('form');
        
        if (forms.length > 0) {
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const requiredFields = form.querySelectorAll('[required]');
                    let isValid = true;
                    
                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            isValid = false;
                            field.classList.add('error');
                            
                            // إنشاء رسالة خطأ إذا لم تكن موجودة
                            let errorMessage = field.nextElementSibling;
                            if (!errorMessage || !errorMessage.classList.contains('error-message')) {
                                errorMessage = document.createElement('div');
                                errorMessage.className = 'error-message';
                                errorMessage.textContent = 'هذا الحقل مطلوب';
                                field.parentNode.insertBefore(errorMessage, field.nextSibling);
                            }
                        } else {
                            field.classList.remove('error');
                            
                            // إزالة رسالة الخطأ إذا كانت موجودة
                            const errorMessage = field.nextElementSibling;
                            if (errorMessage && errorMessage.classList.contains('error-message')) {
                                errorMessage.remove();
                            }
                        }
                    });
                    
                    if (!isValid) {
                        e.preventDefault();
                    }
                });
                
                // إزالة تنسيق الخطأ عند الكتابة
                const inputFields = form.querySelectorAll('input, textarea, select');
                inputFields.forEach(field => {
                    field.addEventListener('input', function() {
                        if (field.value.trim()) {
                            field.classList.remove('error');
                            
                            // إزالة رسالة الخطأ إذا كانت موجودة
                            const errorMessage = field.nextElementSibling;
                            if (errorMessage && errorMessage.classList.contains('error-message')) {
                                errorMessage.remove();
                            }
                        }
                    });
                });
            });
        }
        
        // تفعيل نموذج تسجيل الدخول
        const loginForm = document.querySelector('#login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const username = document.querySelector('#username').value.trim();
                const password = document.querySelector('#password').value.trim();
                
                if (username && password) {
                    // محاكاة عملية تسجيل الدخول
                    const loginButton = loginForm.querySelector('button[type="submit"]');
                    const originalText = loginButton.textContent;
                    
                    loginButton.disabled = true;
                    loginButton.innerHTML = '<span class="spinner"></span> جاري تسجيل الدخول...';
                    
                    setTimeout(() => {
                        // التحقق من صحة بيانات الدخول (يجب استبدالها بطلب API حقيقي)
                        if (validateBrokerCredentials(username, password)) {
                            window.location.href = 'index.html';
                        } else {
                            const errorMessage = document.createElement('div');
                            errorMessage.className = 'error-message text-center mb-20';
                            errorMessage.textContent = 'اسم المستخدم أو كلمة المرور غير صحيحة';
                            
                            const existingError = loginForm.querySelector('.error-message');
                            if (existingError) {
                                existingError.remove();
                            }
                            
                            loginForm.insertBefore(errorMessage, loginForm.firstChild);
                            
                            loginButton.disabled = false;
                            loginButton.textContent = originalText;
                        }
                    }, 1500);
                }
            });
        }
    },

    // إعداد علامات التبويب
    setupTabs: function() {
        const tabContainers = document.querySelectorAll('.tabs-container');
        
        if (tabContainers.length > 0) {
            tabContainers.forEach(container => {
                const tabs = container.querySelectorAll('.tab');
                const tabPanels = container.querySelectorAll('.tab-panel');
                
                tabs.forEach(tab => {
                    tab.addEventListener('click', function() {
                        const target = this.getAttribute('data-target');
                        
                        // إزالة الفئة النشطة من جميع علامات التبويب
                        tabs.forEach(t => t.classList.remove('active'));
                        
                        // إضافة الفئة النشطة إلى علامة التبويب المحددة
                        this.classList.add('active');
                        
                        // إخفاء جميع لوحات علامات التبويب
                        tabPanels.forEach(panel => panel.classList.remove('active'));
                        
                        // إظهار لوحة علامة التبويب المحددة
                        const targetPanel = container.querySelector(`.tab-panel[data-id="${target}"]`);
                        if (targetPanel) {
                            targetPanel.classList.add('active');
                        }
                    });
                });
            });
        }
        
        // تفعيل علامات تبويب واجهات المستخدم
        const interfaceTabs = document.querySelectorAll('.interface-tab');
        if (interfaceTabs.length > 0) {
            interfaceTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const target = this.getAttribute('data-target');
                    
                    // إزالة الفئة النشطة من جميع علامات التبويب
                    interfaceTabs.forEach(t => t.classList.remove('active'));
                    
                    // إضافة الفئة النشطة إلى علامة التبويب المحددة
                    this.classList.add('active');
                    
                    // إخفاء جميع لوحات علامات التبويب
                    document.querySelectorAll('.interface-panel').forEach(panel => panel.classList.remove('active'));
                    
                    // إظهار لوحة علامة التبويب المحددة
                    const targetPanel = document.querySelector(`.interface-panel[data-id="${target}"]`);
                    if (targetPanel) {
                        targetPanel.classList.add('active');
                    }
                });
            });
        }
        
        // تفعيل علامات تبويب تسجيل الدخول
        const loginTabs = document.querySelectorAll('.login-tab');
        if (loginTabs.length > 0) {
            loginTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع علامات التبويب
                    loginTabs.forEach(t => t.classList.remove('active'));
                    
                    // إضافة الفئة النشطة إلى علامة التبويب المحددة
                    this.classList.add('active');
                    
                    // تحديث نص الزر وحقول النموذج بناءً على نوع المستخدم
                    const loginButton = document.querySelector('#login-form button[type="submit"]');
                    const usernameLabel = document.querySelector('label[for="username"]');
                    
                    if (this.textContent.includes('وسيط فرد')) {
                        loginButton.textContent = 'تسجيل دخول كوسيط فرد';
                        usernameLabel.textContent = 'الاسم الأول والأخير';
                    } else {
                        loginButton.textContent = 'تسجيل دخول كمنشأة عقارية';
                        usernameLabel.textContent = 'اسم المنشأة';
                    }
                });
            });
        }
    },

    // إعداد القائمة للأجهزة المحمولة
    setupMobileMenu: function() {
        const menuToggle = document.querySelector('.menu-toggle');
        const mobileMenu = document.querySelector('.mobile-menu');
        
        if (menuToggle && mobileMenu) {
            menuToggle.addEventListener('click', function() {
                this.classList.toggle('active');
                mobileMenu.classList.toggle('active');
                document.body.classList.toggle('menu-open');
            });
            
            // إغلاق القائمة عند النقر على الروابط
            const mobileLinks = mobileMenu.querySelectorAll('a');
            mobileLinks.forEach(link => {
                link.addEventListener('click', function() {
                    menuToggle.classList.remove('active');
                    mobileMenu.classList.remove('active');
                    document.body.classList.remove('menu-open');
                });
            });
        }
    },

    // إعداد التحميل الكسول للصور
    setupLazyLoading: function() {
        if ('IntersectionObserver' in window) {
            const lazyImages = document.querySelectorAll('.lazy-load');
            
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.add('loaded');
                        observer.unobserve(img);
                    }
                });
            });
            
            lazyImages.forEach(img => {
                imageObserver.observe(img);
            });
        } else {
            // التحميل الكسول البديل للمتصفحات القديمة
            const lazyImages = document.querySelectorAll('.lazy-load');
            
            const lazyLoad = function() {
                lazyImages.forEach(img => {
                    if (img.getBoundingClientRect().top < window.innerHeight + 300 && !img.classList.contains('loaded')) {
                        img.src = img.dataset.src;
                        img.classList.add('loaded');
                    }
                });
            };
            
            window.addEventListener('scroll', lazyLoad);
            window.addEventListener('resize', lazyLoad);
            window.addEventListener('orientationchange', lazyLoad);
            lazyLoad(); // تشغيل مرة واحدة عند التحميل
        }
    },

    // إعداد ميزات الوسيط العقاري
    setupBrokerFeatures: function() {
        // تفعيل لوحة تحكم الوسيط
        const brokerDashboard = document.querySelector('.broker-dashboard');
        if (brokerDashboard) {
            // تحميل بيانات الوسيط
            this.loadBrokerData();
            
            // تفعيل مخطط الإحصائيات
            this.setupBrokerStats();
            
            // تفعيل جدول العقارات
            this.setupPropertyTable();
            
            // تفعيل نظام الإشعارات
            this.setupNotifications();
            
            // تفعيل نظام النقاط والمكافآت
            this.setupRewardsSystem();
        }
        
        // تفعيل صفحة إضافة عقار
        const addPropertyForm = document.querySelector('#add-property-form');
        if (addPropertyForm) {
            this.setupPropertyForm();
        }
        
        // تفعيل برنامج الانتشار المبكر
        const earlyAdopterProgram = document.querySelector('.early-adopter-program');
        if (earlyAdopterProgram) {
            this.setupEarlyAdopterProgram();
        }
    },

    // تحميل بيانات الوسيط
    loadBrokerData: function() {
        // محاكاة تحميل بيانات الوسيط (يجب استبدالها بطلب API حقيقي)
        const brokerInfo = document.querySelector('.broker-info');
        if (brokerInfo) {
            const brokerName = localStorage.getItem('broker_name') || 'محمد العتيبي';
            const brokerLicense = localStorage.getItem('broker_license') || 'VAL-12345';
            
            const nameElement = brokerInfo.querySelector('.broker-name');
            const licenseElement = brokerInfo.querySelector('.broker-license');
            
            if (nameElement) nameElement.textContent = brokerName;
            if (licenseElement) licenseElement.textContent = `رقم الرخصة: ${brokerLicense}`;
        }
    },

    // إعداد مخطط الإحصائيات
    setupBrokerStats: function() {
        const statsChart = document.querySelector('#broker-stats-chart');
        if (statsChart && window.Chart) {
            new Chart(statsChart, {
                type: 'line',
                data: {
                    labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
                    datasets: [{
                        label: 'العقارات المعروضة',
                        data: [12, 19, 15, 17, 22, 25],
                        borderColor: '#1e5f74',
                        backgroundColor: 'rgba(30, 95, 116, 0.1)',
                        tension: 0.4,
                        fill: true
                    }, {
                        label: 'الصفقات المكتملة',
                        data: [5, 7, 6, 9, 12, 15],
                        borderColor: '#ffa62b',
                        backgroundColor: 'rgba(255, 166, 43, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'إحصائيات النشاط'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    },

    // إعداد جدول العقارات
    setupPropertyTable: function() {
        const propertyTable = document.querySelector('.property-table');
        if (propertyTable) {
            // تفعيل الفرز
            const sortButtons = propertyTable.querySelectorAll('.sort-button');
            sortButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const column = this.dataset.column;
                    const currentDirection = this.dataset.direction || 'asc';
                    const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
                    
                    // إزالة اتجاه الفرز من جميع الأزرار
                    sortButtons.forEach(btn => {
                        btn.dataset.direction = '';
                        btn.querySelector('i').className = 'fas fa-sort';
                    });
                    
                    // تحديث اتجاه الفرز للزر المحدد
                    this.dataset.direction = newDirection;
                    this.querySelector('i').className = newDirection === 'asc' ? 'fas fa-sort-up' : 'fas fa-sort-down';
                    
                    // فرز الصفوف
                    const rows = Array.from(propertyTable.querySelectorAll('tbody tr'));
                    rows.sort((a, b) => {
                        const aValue = a.querySelector(`td[data-column="${column}"]`).textContent;
                        const bValue = b.querySelector(`td[data-column="${column}"]`).textContent;
                        
                        if (column === 'price' || column === 'date') {
                            // فرز رقمي
                            return newDirection === 'asc' ? 
                                parseFloat(aValue) - parseFloat(bValue) : 
                                parseFloat(bValue) - parseFloat(aValue);
                        } else {
                            // فرز نصي
                            return newDirection === 'asc' ? 
                                aValue.localeCompare(bValue, 'ar') : 
                                bValue.localeCompare(aValue, 'ar');
                        }
                    });
                    
                    // إعادة ترتيب الصفوف
                    const tbody = propertyTable.querySelector('tbody');
                    rows.forEach(row => tbody.appendChild(row));
                });
            });
            
            // تفعيل البحث
            const searchInput = document.querySelector('#property-search');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.trim().toLowerCase();
                    const rows = propertyTable.querySelectorAll('tbody tr');
                    
                    rows.forEach(row => {
                        const text = row.textContent.toLowerCase();
                        row.style.display = text.includes(searchTerm) ? '' : 'none';
                    });
                });
            }
        }
    },

    // إعداد نظام الإشعارات
    setupNotifications: function() {
        const notificationBell = document.querySelector('.notification-bell');
        const notificationPanel = document.querySelector('.notification-panel');
        
        if (notificationBell && notificationPanel) {
            notificationBell.addEventListener('click', function(e) {
                e.preventDefault();
                notificationPanel.classList.toggle('active');
                
                // تحديث حالة الإشعارات
                if (notificationPanel.classList.contains('active')) {
                    // محاكاة تحميل الإشعارات (يجب استبدالها بطلب API حقيقي)
                    const notificationList = notificationPanel.querySelector('.notification-list');
                    if (notificationList) {
                        notificationList.innerHTML = `
                            <div class="notification-item unread">
                                <div class="notification-icon"><i class="fas fa-home"></i></div>
                                <div class="notification-content">
                                    <h4>عقار جديد في منطقتك</h4>
                                    <p>تم إضافة عقار جديد في منطقة الرياض يتوافق مع معايير البحث الخاصة بك.</p>
                                    <span class="notification-time">منذ 5 دقائق</span>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon"><i class="fas fa-user"></i></div>
                                <div class="notification-content">
                                    <h4>طلب جديد من عميل</h4>
                                    <p>لديك طلب جديد من عميل يبحث عن شقة في منطقة جدة.</p>
                                    <span class="notification-time">منذ 3 ساعات</span>
                                </div>
                            </div>
                            <div class="notification-item">
                                <div class="notification-icon"><i class="fas fa-star"></i></div>
                                <div class="notification-content">
                                    <h4>تقييم جديد</h4>
                                    <p>حصلت على تقييم 5 نجوم من أحد العملاء!</p>
                                    <span class="notification-time">منذ يوم</span>
                                </div>
                            </div>
                        `;
                    }
                    
                    // إزالة مؤشر الإشعارات الجديدة
                    notificationBell.classList.remove('has-notifications');
                }
            });
            
            // إغلاق لوحة الإشعارات عند النقر خارجها
            document.addEventListener('click', function(e) {
                if (!notificationBell.contains(e.target) && !notificationPanel.contains(e.target)) {
                    notificationPanel.classList.remove('active');
                }
            });
        }
    },

    // إعداد نظام النقاط والمكافآت
    setupRewardsSystem: function() {
        const rewardsPanel = document.querySelector('.rewards-panel');
        if (rewardsPanel) {
            // محاكاة تحميل بيانات النقاط (يجب استبدالها بطلب API حقيقي)
            const pointsElement = rewardsPanel.querySelector('.broker-points');
            const levelElement = rewardsPanel.querySelector('.broker-level');
            
            if (pointsElement) {
                const points = localStorage.getItem('broker_points') || 750;
                pointsElement.textContent = points;
                
                // تحديث شريط التقدم
                const progressBar = rewardsPanel.querySelector('.progress-bar');
                if (progressBar) {
                    const level = Math.floor(points / 1000) + 1;
                    const progress = (points % 1000) / 10; // النسبة المئوية للتقدم نحو المستوى التالي
                    
                    progressBar.style.width = `${progress}%`;
                    if (levelElement) levelElement.textContent = level;
                }
            }
            
            // تفعيل أزرار المكافآت
            const rewardButtons = rewardsPanel.querySelectorAll('.reward-button');
            rewardButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const pointsCost = parseInt(this.dataset.points);
                    const currentPoints = parseInt(pointsElement.textContent);
                    
                    if (currentPoints >= pointsCost) {
                        // محاكاة استبدال المكافأة
                        const newPoints = currentPoints - pointsCost;
                        pointsElement.textContent = newPoints;
                        localStorage.setItem('broker_points', newPoints);
                        
                        // تحديث شريط التقدم
                        const progressBar = rewardsPanel.querySelector('.progress-bar');
                        if (progressBar) {
                            const level = Math.floor(newPoints / 1000) + 1;
                            const progress = (newPoints % 1000) / 10;
                            
                            progressBar.style.width = `${progress}%`;
                            if (levelElement) levelElement.textContent = level;
                        }
                        
                        // إظهار رسالة نجاح
                        const notification = document.createElement('div');
                        notification.className = 'notification success';
                        notification.textContent = 'تم استبدال المكافأة بنجاح!';
                        document.body.appendChild(notification);
                        
                        setTimeout(() => {
                            notification.classList.add('show');
                        }, 10);
                        
                        setTimeout(() => {
                            notification.classList.remove('show');
                            setTimeout(() => {
                                document.body.removeChild(notification);
                            }, 300);
                        }, 3000);
                    } else {
                        // إظهار رسالة خطأ
                        const notification = document.createElement('div');
                        notification.className = 'notification error';
                        notification.textContent = 'نقاط غير كافية لاستبدال هذه المكافأة!';
                        document.body.appendChild(notification);
                        
                        setTimeout(() => {
                            notification.classList.add('show');
                        }, 10);
                        
                        setTimeout(() => {
                            notification.classList.remove('show');
                            setTimeout(() => {
                                document.body.removeChild(notification);
                            }, 300);
                        }, 3000);
                    }
                });
            });
        }
    },

    // إعداد نموذج إضافة عقار
    setupPropertyForm: function() {
        const propertyForm = document.querySelector('#add-property-form');
        if (propertyForm) {
            // تفعيل رفع الصور
            const imageUpload = propertyForm.querySelector('#property-images');
            const imagePreview = propertyForm.querySelector('.image-preview');
            
            if (imageUpload && imagePreview) {
                imageUpload.addEventListener('change', function() {
                    imagePreview.innerHTML = '';
                    
                    if (this.files) {
                        Array.from(this.files).forEach(file => {
                            if (file.type.match('image.*')) {
                                const reader = new FileReader();
                                
                                reader.onload = function(e) {
                                    const img = document.createElement('div');
                                    img.className = 'preview-item';
                                    img.innerHTML = `
                                        <img src="${e.target.result}" alt="صورة العقار">
                                        <button type="button" class="remove-image"><i class="fas fa-times"></i></button>
                                    `;
                                    imagePreview.appendChild(img);
                                    
                                    // تفعيل زر الحذف
                                    img.querySelector('.remove-image').addEventListener('click', function() {
                                        img.remove();
                                    });
                                };
                                
                                reader.readAsDataURL(file);
                            }
                        });
                    }
                });
            }
            
            // تفعيل خريطة الموقع
            const mapContainer = propertyForm.querySelector('#property-map');
            if (mapContainer && window.google && window.google.maps) {
                const map = new google.maps.Map(mapContainer, {
                    center: { lat: 24.7136, lng: 46.6753 }, // الرياض
                    zoom: 12
                });
                
                const marker = new google.maps.Marker({
                    position: { lat: 24.7136, lng: 46.6753 },
                    map: map,
                    draggable: true
                });
                
                // تحديث الإحداثيات عند تحريك العلامة
                google.maps.event.addListener(marker, 'dragend', function() {
                    const position = marker.getPosition();
                    document.querySelector('#property-lat').value = position.lat();
                    document.querySelector('#property-lng').value = position.lng();
                });
                
                // تفعيل البحث عن الموقع
                const locationSearch = propertyForm.querySelector('#property-location-search');
                if (locationSearch) {
                    const autocomplete = new google.maps.places.Autocomplete(locationSearch);
                    autocomplete.addListener('place_changed', function() {
                        const place = autocomplete.getPlace();
                        if (place.geometry) {
                            map.setCenter(place.geometry.location);
                            marker.setPosition(place.geometry.location);
                            
                            document.querySelector('#property-lat').value = place.geometry.location.lat();
                            document.querySelector('#property-lng').value = place.geometry.location.lng();
                        }
                    });
                }
            }
            
            // تفعيل حقل السعر
            const priceInput = propertyForm.querySelector('#property-price');
            if (priceInput) {
                priceInput.addEventListener('input', function() {
                    // إزالة كل شيء ما عدا الأرقام
                    let value = this.value.replace(/[^\d]/g, '');
                    
                    // تنسيق الرقم بفواصل
                    if (value) {
                        value = parseInt(value).toLocaleString('ar-SA');
                    }
                    
                    this.value = value;
                });
            }
            
            // تفعيل إرسال النموذج
            propertyForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // محاكاة إرسال النموذج
                const submitButton = propertyForm.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;
                
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner"></span> جاري الإرسال...';
                
                setTimeout(() => {
                    // إظهار رسالة نجاح
                    const successMessage = document.createElement('div');
                    successMessage.className = 'success-message';
                    successMessage.innerHTML = `
                        <i class="fas fa-check-circle"></i>
                        <h3>تم إضافة العقار بنجاح!</h3>
                        <p>سيتم مراجعة العقار ونشره قريباً.</p>
                    `;
                    
                    propertyForm.innerHTML = '';
                    propertyForm.appendChild(successMessage);
                    
                    // إعادة التوجيه بعد فترة
                    setTimeout(() => {
                        window.location.href = 'profile.html';
                    }, 3000);
                }, 2000);
            });
        }
    },

    // إعداد برنامج الانتشار المبكر
    setupEarlyAdopterProgram: function() {
        const referralLink = document.querySelector('#referral-link');
        const copyButton = document.querySelector('#copy-referral');
        
        if (referralLink && copyButton) {
            // إنشاء رابط الإحالة
            const brokerId = localStorage.getItem('broker_id') || '12345';
            const referralUrl = `https://wasset.sa/register?ref=${brokerId}`;
            referralLink.value = referralUrl;
            
            // تفعيل زر النسخ
            copyButton.addEventListener('click', function() {
                referralLink.select();
                document.execCommand('copy');
                
                // تغيير نص الزر مؤقتاً
                const originalText = this.textContent;
                this.textContent = 'تم النسخ!';
                
                setTimeout(() => {
                    this.textContent = originalText;
                }, 2000);
            });
        }
        
        // تفعيل مخطط الإحالات
        const referralsChart = document.querySelector('#referrals-chart');
        if (referralsChart && window.Chart) {
            new Chart(referralsChart, {
                type: 'bar',
                data: {
                    labels: ['الأسبوع 1', 'الأسبوع 2', 'الأسبوع 3', 'الأسبوع 4'],
                    datasets: [{
                        label: 'الوسطاء المنضمين',
                        data: [5, 8, 12, 15],
                        backgroundColor: '#1e5f74'
                    }, {
                        label: 'العمولات المكتسبة',
                        data: [2, 4, 6, 8],
                        backgroundColor: '#ffa62b'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'إحصائيات برنامج الانتشار المبكر'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }
};

// التحقق من صحة بيانات الوسيط (وظيفة مساعدة)
function validateBrokerCredentials(username, password) {
    // محاكاة التحقق من بيانات الوسيط (يجب استبدالها بطلب API حقيقي)
    // في هذا المثال، أي اسم مستخدم وكلمة مرور تحتوي على أكثر من 3 أحرف ستكون صالحة
    if (username.length > 3 && password.length > 3) {
        // حفظ بيانات الوسيط في التخزين المحلي للاستخدام في الصفحات الأخرى
        localStorage.setItem('broker_name', username);
        localStorage.setItem('broker_id', Math.floor(Math.random() * 10000).toString());
        localStorage.setItem('broker_license', 'VAL-' + Math.floor(Math.random() * 100000).toString());
        localStorage.setItem('broker_points', '750');
        
        return true;
    }
    
    return false;
}

// تهيئة المنصة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    wasset.init();
});
